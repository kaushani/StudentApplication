package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.entities.Student;
import com.cg.exception.StudentException;

@Repository
public class StudentDAOImpl implements IStudentDAO{

	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public int addStudent(Student question)  throws StudentException {
		int questionNo = 0;
		
		try
		{
		em.persist(question);
		em.flush();
		questionNo=question.getStudentId();
		}catch(Exception e)
		{
			throw new StudentException("Exception in DAO "+ e.getMessage());
		}
		
		return questionNo;
		
	}

	

}
